"""TASK 2 - Online DFS rover in unknown mazes + competitive ratio (Python 3)."""
import random, json
from collections import deque
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def make_maze(n, braid, rng):
    """n odd. Perfect maze (recursive backtracker); then 'braid' = probability that each dead end is
    opened up to a neighbouring passage (creates loops -> fewer dead ends)."""
    g = [[1] * n for _ in range(n)]
    g[1][1] = 0; stack = [(1, 1)]
    while stack:
        r, c = stack[-1]
        opts = [(dr, dc) for dr, dc in ((-2, 0), (2, 0), (0, -2), (0, 2))
                if 0 < r + dr < n - 1 and 0 < c + dc < n - 1 and g[r + dr][c + dc] == 1]
        if not opts: stack.pop(); continue
        dr, dc = rng.choice(opts)
        g[r + dr // 2][c + dc // 2] = 0; g[r + dr][c + dc] = 0; stack.append((r + dr, c + dc))
    if braid > 0:
        for r in range(1, n - 1, 2):
            for c in range(1, n - 1, 2):
                if len(free_nbrs(g, (r, c))) == 1 and rng.random() < braid:
                    cand = [(dr, dc) for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1))
                            if 0 < r + 2 * dr < n - 1 and 0 < c + 2 * dc < n - 1 and g[r + dr][c + dc] == 1]
                    if cand:
                        dr, dc = rng.choice(cand); g[r + dr][c + dc] = 0
    return g

def free_nbrs(g, p):
    r, c = p
    return [(r + dr, c + dc) for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1))
            if 0 <= r + dr < len(g) and 0 <= c + dc < len(g) and g[r + dr][c + dc] == 0]

def count_dead_ends(g):
    return sum(1 for r in range(len(g)) for c in range(len(g)) if g[r][c] == 0 and len(free_nbrs(g, (r, c))) == 1)

def bfs_dist(g, s):
    d = {s: 0}; q = deque([s])
    while q:
        p = q.popleft()
        for x in free_nbrs(g, p):
            if x not in d: d[x] = d[p] + 1; q.append(x)
    return d

def online_dfs(g, start, goal):
    """Rover sees only the 4 squares around it. Keeps a memory of visited squares and a back-track stack."""
    pos, visited, stack = start, {start}, []
    moves = revisits = 0; trail = [start]
    while True:
        if pos == goal: return dict(found=True, moves=moves, revisits=revisits, trail=trail)
        untried = [q for q in free_nbrs(g, pos) if q not in visited]
        if untried:
            stack.append(pos); pos = untried[0]; visited.add(pos); moves += 1
        elif stack:
            pos = stack.pop(); moves += 1; revisits += 1
        else:
            return dict(found=False, moves=moves, revisits=revisits, trail=trail)
        trail.append(pos)

def pick_targets(g, rng):
    start = (1, 1); d = bfs_dist(g, start); n = len(g)
    cells = [p for p in d if p != start]
    near = min(cells, key=lambda p: (abs(d[p] - 6), rng.random()))
    far = max(cells, key=lambda p: (d[p], rng.random()))
    # unreachable: a sealed pillar square (all four neighbours are walls) -> never modifies the maze
    pillars = [(r, c) for r in range(2, n - 2, 2) for c in range(2, n - 2, 2)
               if all(g[r + dr][c + dc] == 1 for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)))]
    if not pillars: return None
    un = rng.choice(pillars)
    g[un[0]][un[1]] = 0
    return start, dict(Near=near, Far=far, Unreachable=un), d

if __name__ == "__main__":
    SIZES = [11, 21, 31]; LEVELS = {"Many": 0.0, "Few": 0.9}; SEEDS = range(5)
    rows, example = [], None
    print("Online-DFS rover, mean of 5 mazes per row")
    print(f"{'Size':<8}{'DeadEnds':<9}{'(count)':>8}{'Target':<13}{'Moves':>8}{'Revisited':>10}{'Shortest':>9}{'CompRatio':>10}  Found")
    for n in SIZES:
        for lvl, braid in LEVELS.items():
            acc = {t: dict(m=[], r=[], s=[], f=[]) for t in ("Near", "Far", "Unreachable")}; de = []
            for sd in SEEDS:
                rng = random.Random(1000 * n + 10 * sd + int(braid * 10))
                while True:                       # re-sample until a sealed square exists
                    g = make_maze(n, braid, rng); dcount = count_dead_ends(g)
                    out = pick_targets(g, rng)
                    if out is not None: break
                de.append(dcount); start, targets, d = out
                for t, goal in targets.items():
                    res = online_dfs(g, start, goal)
                    acc[t]["m"].append(res["moves"]); acc[t]["r"].append(res["revisits"])
                    acc[t]["f"].append(res["found"]); acc[t]["s"].append(d.get(goal))
                    if n == 21 and lvl == "Many" and sd == 0 and t in ("Far", "Unreachable"):
                        example = example or {}; example[t] = (g, start, goal, res)
            for t in ("Near", "Far", "Unreachable"):
                m = sum(acc[t]["m"]) / 5; r = sum(acc[t]["r"]) / 5
                if t == "Unreachable": s, ratio = None, None
                else:
                    s = sum(acc[t]["s"]) / 5; ratio = round(m / s, 2)
                rows.append(dict(size=f"{n}x{n}", dead_ends=lvl, dead_end_count=round(sum(de) / 5, 1), target=t,
                                 moves=round(m, 1), revisited=round(r, 1), shortest=None if s is None else round(s, 1),
                                 ratio=ratio, found=f"{sum(acc[t]['f'])}/5"))
                x = rows[-1]
                print(f"{x['size']:<8}{lvl:<9}{x['dead_end_count']:>8}{t:<13}{x['moves']:>8}{x['revisited']:>10}"
                      f"{str(x['shortest'] if s is not None else 'inf'):>9}{str(ratio if ratio is not None else 'n/a'):>10}  {x['found']}")
    json.dump(rows, open("../results/task2.json", "w"), indent=1)

    # Figure 3: example run + ratio chart
    fig, axes = plt.subplots(1, 3, figsize=(13, 4.2))
    for ax, key in zip(axes[:2], ("Far", "Unreachable")):
        g, s, goal, res = example[key]
        cnt = [[0] * len(g) for _ in g]
        for (r, c) in res["trail"]: cnt[r][c] += 1
        img = [[(-1 if g[r][c] else cnt[r][c]) for c in range(len(g))] for r in range(len(g))]
        import numpy as np
        a = np.array(img, dtype=float); a[a == -1] = np.nan
        cm = plt.get_cmap("YlOrRd").copy(); cm.set_bad("black")
        ax.imshow(a, cmap=cm, vmin=0, vmax=4)
        ax.plot(s[1], s[0], "go", ms=8); ax.plot(goal[1], goal[0], marker="*", color="blue", mec="w", ms=14)
        ax.set_title(f"21x21, many dead ends, target: {key}\nmoves = {res['moves']}, found = {res['found']}", fontsize=9)
        ax.set_xticks([]); ax.set_yticks([])
    for k, t in enumerate(("Near", "Far")):
        for j, lvl in enumerate(("Many", "Few")):
            vals = [x["ratio"] for x in rows if x["target"] == t and x["dead_ends"] == lvl]
            axes[2].bar([i + 0.2 * (2 * k + j - 1.5) for i in range(3)], vals, 0.2, label=f"{t}, {lvl} dead ends")
    axes[2].set_xticks(range(3)); axes[2].set_xticklabels(["11x11", "21x21", "31x31"])
    axes[2].set_ylabel("competitive ratio (moves / BFS shortest)"); axes[2].legend(fontsize=7)
    axes[2].set_title("Competitive ratio (mean of 5 mazes)", fontsize=9)
    plt.tight_layout(); plt.savefig("../figs/fig3_task2_rover.png", dpi=130); plt.close()

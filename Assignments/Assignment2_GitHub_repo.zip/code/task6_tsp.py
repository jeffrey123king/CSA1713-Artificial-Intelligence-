"""TASK 6 - Exhaustive search vs hill-climbing (2-opt + random restarts) for a delivery tour."""
import itertools, math, random, time, json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def make_instance(n, seed):
    rng = random.Random(seed)
    pts = [(rng.uniform(0, 100), rng.uniform(0, 100)) for _ in range(n + 1)]   # index 0 = depot
    d = [[math.dist(a, b) for b in pts] for a in pts]
    return pts, d

def tour_length(d, tour):
    """tour = list of customers in visiting order; depot (0) is added at both ends."""
    total = d[0][tour[0]]
    for i in range(len(tour) - 1): total += d[tour[i]][tour[i + 1]]
    return total + d[tour[-1]][0]

def exhaustive(d, n):
    best, best_tour, count = float("inf"), None, 0
    for perm in itertools.permutations(range(1, n + 1)):     # every ordering of customers
        count += 1
        L = tour_length(d, perm)
        if L < best: best, best_tour = L, perm               # keep best so far
    return best, list(best_tour), count

def two_opt_hill_climb(d, n, rng):
    tour = list(range(1, n + 1)); rng.shuffle(tour)
    L = tour_length(d, tour); improved = True
    while improved:
        improved = False
        for i in range(n - 1):
            for j in range(i + 1, n):
                new = tour[:i] + tour[i:j + 1][::-1] + tour[j + 1:]     # reverse a segment
                nl = tour_length(d, new)
                if nl < L - 1e-12: tour, L, improved = new, nl, True
    return L, tour

def local_search(d, n, restarts, rng):
    best, bt = float("inf"), None
    for _ in range(restarts):
        L, t = two_opt_hill_climb(d, n, rng)
        if L < best: best, bt = L, t
    return best, bt

if __name__ == "__main__":
    # ---- 2. correctness on a 4-customer example with a distance table ----
    D4 = [[0, 10, 15, 20, 12],
          [10, 0, 8, 14, 9],
          [15, 8, 0, 6, 11],
          [20, 14, 6, 0, 7],
          [12, 9, 11, 7, 0]]
    print("Distance table (0 = depot, 1-4 = customers):")
    for r in D4: print("   ", r)
    print("\nAll 4! = 24 tours:")
    res4 = []
    for perm in itertools.permutations(range(1, 5)):
        L = tour_length(D4, perm); res4.append((perm, L))
        path = " -> ".join(map(str, (0,) + perm + (0,)))
        terms = " + ".join(str(x) for x in [D4[0][perm[0]]] + [D4[perm[i]][perm[i + 1]] for i in range(3)] + [D4[perm[-1]][0]])
        print(f"  {path}   = {terms} = {L}")
    b4 = exhaustive(D4, 4)
    print(f"\nProgram result: best distance = {b4[0]}, best tour = 0 -> {' -> '.join(map(str, b4[1]))} -> 0, tours checked = {b4[2]}")
    hand_min = min(L for _, L in res4)
    print(f"Minimum of the 24 listed tours = {hand_min}  (same as program: {hand_min == b4[0]})")
    json.dump(dict(tours=[(list(p), L) for p, L in res4], best=b4[0]), open("../results/task6_example4.json", "w"))

    # ---- 3. growth of exhaustive search ----
    print("\nExhaustive search growth (random instance, seed 11)")
    print(f"{'n':>3}{'Predicted n!':>14}{'Actual tours':>14}{'Time (s)':>10}{'x slower than n-1':>19}")
    growth, prev = [], None
    for n in range(4, 11):
        pts, d = make_instance(n, 11)
        t0 = time.perf_counter(); best, bt, cnt = exhaustive(d, n); t = time.perf_counter() - t0
        growth.append(dict(n=n, predicted=math.factorial(n), actual=cnt, time=t))
        print(f"{n:>3}{math.factorial(n):>14}{cnt:>14}{t:>10.3f}{('-' if prev is None else format(t / prev, '.1f')):>19}")
        prev = t
    print(f"Extrapolation: n=11 needs {math.factorial(11)} tours, about {growth[-1]['time'] * 11:.0f} s; n=12 about {growth[-1]['time'] * 11 * 12 / 60:.0f} min")

    # ---- 4. local search vs exhaustive on n = 9 (3 instances x 20 runs) ----
    print("\nLocal search (2-opt hill climbing + random restarts), n = 9, 20 runs per row")
    print(f"{'instance':>9}{'restarts':>9}{'exh. best':>10}{'avg % above':>12}{'worst %':>9}{'#optimal/20':>12}{'avg time s':>11}")
    ls_rows = []; fig_data = None
    for seed in (11, 12, 13):
        pts, d = make_instance(9, seed)
        best, bt, _ = exhaustive(d, 9)
        for R in (1, 3, 10):
            gaps, times = [], []
            for run in range(20):
                rng = random.Random(1000 * seed + 10 * R + run)
                t0 = time.perf_counter(); L, t = local_search(d, 9, R, rng); times.append(time.perf_counter() - t0)
                gaps.append((L - best) / best * 100)
            row = dict(instance=seed, restarts=R, exhaustive_best=round(best, 2), avg_gap=sum(gaps) / 20, worst_gap=max(gaps),
                       optimal_runs=sum(g < 1e-9 for g in gaps), avg_time=sum(times) / 20, gaps=gaps)
            ls_rows.append(row)
            print(f"{seed:>9}{R:>9}{best:>10.2f}{row['avg_gap']:>12.2f}{row['worst_gap']:>9.2f}{row['optimal_runs']:>12}{row['avg_time']:>11.5f}")
            if seed == 11 and R == 1: fig_data = (pts, bt, gaps)
    # larger n
    print("\nLocal search at sizes where exhaustive search is impossible (10 restarts, mean of 5 runs)")
    print(f"{'n':>4}{'avg length':>11}{'avg time s':>11}")
    big = []
    for n in (12, 15, 20, 30):
        pts, d = make_instance(n, 21); Ls, ts = [], []
        for run in range(5):
            t0 = time.perf_counter(); L, _ = local_search(d, n, 10, random.Random(run)); ts.append(time.perf_counter() - t0); Ls.append(L)
        big.append(dict(n=n, length=sum(Ls) / 5, time=sum(ts) / 5))
        print(f"{n:>4}{big[-1]['length']:>11.1f}{big[-1]['time']:>11.4f}")
    json.dump(dict(growth=growth, ls=ls_rows, big=big), open("../results/task6.json", "w"), indent=1)

    # figures
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.8))
    ns = [g["n"] for g in growth]
    axes[0].plot(ns, [g["actual"] for g in growth], "o-", label="tours checked (n!)"); axes[0].set_yscale("log")
    axes[0].set_xlabel("customers n"); axes[0].set_ylabel("tours (log)"); axes[0].grid(alpha=.3)
    axes[1].plot(ns, [g["time"] for g in growth], "s-r"); axes[1].axhline(2.0, color="k", ls=":", label="2 s limit")
    axes[1].set_yscale("log"); axes[1].set_xlabel("customers n"); axes[1].set_ylabel("time (s, log)"); axes[1].legend(); axes[1].grid(alpha=.3)
    axes[0].legend(); plt.tight_layout(); plt.savefig("../figs/fig8_task6_growth.png", dpi=130); plt.close()

    pts, bt, gaps = fig_data
    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    order = [0] + bt + [0]
    axes[0].plot([pts[i][0] for i in order], [pts[i][1] for i in order], "g-o")
    axes[0].plot(*pts[0], "rs", ms=10); axes[0].set_title("Optimal tour found by exhaustive search (n = 9)", fontsize=9)
    for i, p in enumerate(pts): axes[0].annotate(str(i), p, textcoords="offset points", xytext=(4, 4), fontsize=8)
    axes[1].bar(range(20), gaps, color=["g" if g < 1e-9 else "orange" for g in gaps])
    axes[1].set_xlabel("run number"); axes[1].set_ylabel("% above best"); axes[1].set_title("20 runs, 1 restart each (green = optimal)", fontsize=9)
    plt.tight_layout(); plt.savefig("../figs/fig9_task6_local.png", dpi=130); plt.close()

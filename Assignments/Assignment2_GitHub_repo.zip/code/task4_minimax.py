"""TASK 4 - Depth-limited minimax on Tic-Tac-Toe (3x3, 3 in a row) and 4x4 (4 in a row)."""
import random, time, json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

class Game:
    def __init__(self, n):
        self.n, self.k = n, n               # n x n board, n in a row to win
        self.lines = []
        for r in range(n): self.lines.append([r * n + c for c in range(n)])
        for c in range(n): self.lines.append([r * n + c for r in range(n)])
        self.lines.append([i * n + i for i in range(n)]); self.lines.append([i * n + (n - 1 - i) for i in range(n)])
        self.through = [[l for l in self.lines if i in l] for i in range(n * n)]

    def won(self, b, move):                 # did the player who just played `move` win?
        p = b[move]
        return any(all(b[i] == p for i in l) for l in self.through[move])

    def evaluate(self, b, me):
        """EVALUATION FUNCTION: (# lines still open for me) - (# lines still open for the opponent).
        A line is open for a player if it contains no mark of the other player."""
        op = -me; mine = theirs = 0
        for l in self.lines:
            vals = [b[i] for i in l]
            if op not in vals: mine += 1
            if me not in vals: theirs += 1
        return mine - theirs

class Stats:
    def __init__(self): self.expanded = 0; self.evals = 0

def minimax(g, b, player, depth, me, last, empties, st):
    if last is not None and g.won(b, last):
        st.evals += 1
        return (1000 + depth) if b[last] == me else -(1000 + depth)
    if empties == 0:
        st.evals += 1; return 0
    if depth == 0:
        st.evals += 1; return g.evaluate(b, me)
    st.expanded += 1
    best = -10**9 if player == me else 10**9
    for m in range(len(b)):
        if b[m] == 0:
            b[m] = player
            v = minimax(g, b, -player, depth - 1, me, m, empties - 1, st)
            b[m] = 0
            best = max(best, v) if player == me else min(best, v)
    return best

def best_move(g, b, player, depth, rng):
    st = Stats(); scores = []
    empties = b.count(0)
    st.expanded += 1                      # the root position itself is expanded
    for m in range(len(b)):
        if b[m] == 0:
            b[m] = player
            v = minimax(g, b, -player, depth - 1, player, m, empties - 1, st)
            b[m] = 0; scores.append((v, m))
    top = max(s for s, _ in scores)
    return rng.choice([m for s, m in scores if s == top]), st, 1  # (move, stats)

def play_game(g, depth, ai_first, rng):
    b = [0] * (g.n * g.n); player = 1; ai = 1 if ai_first else -1; last = None; times = []
    while True:
        empties = b.count(0)
        if player == ai:
            t0 = time.perf_counter(); m, _, _ = best_move(g, b, player, depth, rng); times.append(time.perf_counter() - t0)
        else:
            m = rng.choice([i for i in range(len(b)) if b[i] == 0])
        b[m] = player
        if g.won(b, m): return ("win" if player == ai else "loss"), times
        if empties == 1: return "draw", times
        player = -player

def theory(b0, d):
    total, term = 1, 1
    for i in range(d):
        term *= (b0 - i); total += term
    return total

if __name__ == "__main__":
    print("Evaluation function: f(board) = (open lines for me) - (open lines for opponent)")
    print("Worked check, empty 3x3 board: f =", Game(3).evaluate([0] * 9, 1), "(8 - 8)")
    b = [1, 0, 0, 0, -1, 0, 0, 0, 0]
    print("3x3 board X in corner, O in centre, X to evaluate: f =", Game(3).evaluate(b, 1))
    print()
    cases = [(3, 1), (3, 2), (3, 3), (3, 4), (3, 9), (4, 1), (4, 2), (4, 3), (4, 4), (4, 5)]
    GAMES = 20; rows = []
    hdr = (f"{'Board':<6}{'Depth':>6}{'Expanded':>10}{'EvalCalls':>10}{'Total pos':>10}{'Theory(exact)':>14}"
           f"{'Theory(1+b+..)':>15}{'Time 1st move s':>16}{'W/D/L':>10}{'Win rate':>9}{'avg s/move':>11}")
    print(hdr)
    for n, d in cases:
        g = Game(n); rng = random.Random(42)
        empty = [0] * (n * n); st_total = Stats()
        t0 = time.perf_counter(); _, st, _ = best_move(g, empty, 1, d, rng); t1 = time.perf_counter() - t0
        total = st.expanded + st.evals
        th_exact = theory(n * n, d); th_const = sum((n * n) ** i for i in range(d + 1))
        if n == 4 and d == 5:
            wdl, wr, avg_t = "-", None, None
        else:
            w = dr = l = 0; tt = []
            for gm in range(GAMES):
                res, times = play_game(g, d, gm % 2 == 0, random.Random(500 + gm)); tt += times
                w += res == "win"; dr += res == "draw"; l += res == "loss"
            wdl = f"{w}/{dr}/{l}"; wr = w / GAMES; avg_t = sum(tt) / len(tt)
        rows.append(dict(board=f"{n}x{n}", depth=d, expanded=st.expanded, evals=st.evals, total=total,
                         theory_exact=th_exact, theory_const=th_const, time_first=round(t1, 4),
                         wdl=wdl, win_rate=wr, avg_move_time=avg_t))
        print(f"{n}x{n:<4}{d:>6}{st.expanded:>10}{st.evals:>10}{total:>10}{th_exact:>14}{th_const:>15}{t1:>16.4f}"
              f"{wdl:>10}{('-' if wr is None else format(wr, '.0%')):>9}{('-' if avg_t is None else format(avg_t, '.4f')):>11}")
    json.dump(rows, open("../results/task4.json", "w"), indent=1)

    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    for n, mk in ((3, "o-"), (4, "s-")):
        rs = [r for r in rows if r["board"] == f"{n}x{n}"]
        axes[0].plot([r["depth"] for r in rs], [r["total"] for r in rs], mk, label=f"{n}x{n} actual")
        axes[0].plot([r["depth"] for r in rs], [r["theory_const"] for r in rs], "--", alpha=.5, label=f"{n}x{n} 1+b+..+b^d")
        axes[1].plot([r["depth"] for r in rs], [r["time_first"] for r in rs], mk, label=f"{n}x{n}")
    axes[0].set_yscale("log"); axes[0].set_xlabel("depth"); axes[0].set_ylabel("positions visited (log)"); axes[0].legend(fontsize=7)
    axes[1].set_yscale("log"); axes[1].axhline(1.0, color="r", ls=":", label="1 s limit"); axes[1].set_xlabel("depth")
    axes[1].set_ylabel("time for first move (s, log)"); axes[1].legend()
    for a in axes: a.grid(alpha=.3)
    plt.tight_layout(); plt.savefig("../figs/fig6_task4_growth.png", dpi=130); plt.close()

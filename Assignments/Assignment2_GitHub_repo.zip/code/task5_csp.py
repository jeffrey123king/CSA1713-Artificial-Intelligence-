"""TASK 5 - Constraint propagation (AC-3) for exam timetabling + backtracking with / without propagation."""
import random, json
from collections import deque
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

class Counter:
    def __init__(self): self.checks = 0; self.wipeouts = 0; self.nodes = 0; self.backtracks = 0

def neighbours_of(edges, n):
    nb = {x: [] for x in range(n)}
    for a, b in edges: nb[a].append(b); nb[b].append(a)
    return nb

def revise(dom, X, Y, cnt, trace=None, names=None):
    """Remove every slot s from dom[X] that has no support in dom[Y] (support = a slot in Y different from s)."""
    changed = False
    for s in sorted(dom[X]):
        supported = False
        for t in dom[Y]:
            cnt.checks += 1
            if t != s: supported = True; break
        if not supported:
            dom[X].discard(s); changed = True
            if trace is not None:
                trace.append((f"remove {s} from {names[X]} (no support in {names[Y]})",
                              {names[k]: sorted(v) for k, v in dom.items()}))
    return changed

def propagate(dom, edges_nb, cnt, queue=None, trace=None, names=None):
    """AC-3. Returns True (success) or False (some domain became empty)."""
    if queue is None:
        queue = deque((X, Y) for X in edges_nb for Y in edges_nb[X])
    while queue:
        X, Y = queue.popleft()
        if revise(dom, X, Y, cnt, trace, names):
            if not dom[X]:
                cnt.wipeouts += 1
                if trace is not None: trace.append((f"{names[X]} is EMPTY -> no solution", {names[k]: sorted(v) for k, v in dom.items()}))
                return False
            for Z in edges_nb[X]:
                if Z != Y: queue.append((Z, X))
    return True

def consistent(var, val, assign, nb, cnt):
    for z in nb[var]:
        if z in assign:
            cnt.checks += 1
            if assign[z] == val: return False
    return True

def backtrack_plain(n, dom0, nb, cnt):
    assign = {}
    def rec(i):
        if i == n: return True
        for v in sorted(dom0[i]):
            cnt.nodes += 1
            if consistent(i, v, assign, nb, cnt):
                assign[i] = v
                if rec(i + 1): return True
                del assign[i]
        cnt.backtracks += 1
        return False
    return dict(assign) if rec(0) else None

def backtrack_mac(n, dom0, nb, cnt):
    dom = {k: set(v) for k, v in dom0.items()}
    if not propagate(dom, nb, cnt): return None
    assign = {}
    def rec(i, dom):
        if i == n: return True
        for v in sorted(dom[i]):
            cnt.nodes += 1
            new = {k: set(x) for k, x in dom.items()}; new[i] = {v}
            if propagate(new, nb, cnt, deque((Z, i) for Z in nb[i])):
                assign[i] = v
                if rec(i + 1, new): return True
                del assign[i]
        cnt.backtracks += 1
        return False
    return dict(assign) if rec(0, dom) else None

def valid(sol, edges): return sol is not None and all(sol[a] != sol[b] for a, b in edges)

def show_trace(title, names, doms, edges):
    nb = neighbours_of(edges, len(names)); dom = {i: set(doms[i]) for i in range(len(names))}
    trace = [("Start", {names[k]: sorted(v) for k, v in dom.items()})]
    cnt = Counter(); ok = propagate(dom, nb, cnt, None, trace, names)
    print(f"--- {title} ---")
    print(f"{'Step':<5}" + "".join(f"{n:>12}" for n in names) + "   Action")
    rows = []
    for i, (act, snap) in enumerate(trace):
        print(f"{i:<5}" + "".join(f"{str(set(snap[n])):>12}" for n in names) + f"   {act}")
        rows.append(dict(step=i, action=act, **{n: sorted(snap[n]) for n in names}))
    solved = ok and all(len(dom[k]) == 1 for k in dom)
    status = "propagation alone SOLVED it" if solved else ("propagation alone proved NO SOLUTION" if not ok else "propagation alone is NOT enough (needs search)")
    print(f"Result: {status}; constraint checks = {cnt.checks}\n")
    return rows, status

if __name__ == "__main__":
    out = {}
    # Instance 1a: propagation alone solves it
    e3 = [(0, 1), (1, 2), (0, 2)]
    out["1a"] = show_trace("Instance 1a (A,B,C all share students; A={1}, B={1,2}, C={1,2,3})", ["A", "B", "C"], [{1}, {1, 2}, {1, 2, 3}], e3)
    # Instance 1b: propagation alone proves no solution
    out["1b"] = show_trace("Instance 1b (A,B share students but both can only use slot 1)", ["A", "B", "C"], [{1}, {1}, {1, 2}], [(0, 1), (1, 2)])
    # The assignment's own hint example: 3 mutually conflicting exams, only 2 slots
    out["1c"] = show_trace("Instance 1c (assignment hint: 3 exams all sharing students, only 2 slots)", ["A", "B", "C"], [{1, 2}, {1, 2}, {1, 2}], e3)
    cnt = Counter(); r = backtrack_mac(3, {0: {1, 2}, 1: {1, 2}, 2: {1, 2}}, neighbours_of(e3, 3), cnt)
    print(f"Instance 1c with backtracking+propagation: solution = {r}, nodes = {cnt.nodes}, backtracks = {cnt.backtracks}\n")

    # Instance 2: harder (8 exams, 3 slots, only A is restricted)
    names = list("ABCDEFGH")
    E2 = [(0,1),(0,2),(1,2),(1,3),(2,3),(2,4),(3,4),(3,5),(4,5),(5,6),(4,6),(6,7),(5,7),(0,7)]
    dom2 = [{1, 2, 3} for _ in range(6)] + [{3}, {1, 2}]      # G must use slot 3, H only slot 1 or 2
    out["2"] = show_trace("Instance 2 (8 exams, 3 slots; G={3}, H={1,2}, others {1,2,3})", names, dom2, E2)
    nb2 = neighbours_of(E2, 8)
    for label, fn in (("plain backtracking", backtrack_plain), ("backtracking + propagation", backtrack_mac)):
        c = Counter(); sol = fn(8, {i: set(d) for i, d in enumerate(dom2)}, nb2, c)
        print(f"Instance 2, {label}: valid solution = {valid(sol, E2)} {sol}; nodes={c.nodes} backtracks={c.backtracks} checks={c.checks} wipeouts={c.wipeouts}")
    print()
    json.dump({k: v[0] for k, v in out.items()}, open("../results/task5_traces.json", "w"), indent=1)

    # ---- scaling comparison (random conflict graphs, 3 slots, edge prob 0.45, 10 seeds each) ----
    SLOTS, P, SEEDS = 3, 0.45, 10
    print(f"Backtracking with / without propagation (random conflict graphs, {SLOTS} slots, p={P}, mean of {SEEDS} seeds)")
    print(f"{'Exams':>5}{'Method':>16}{'Nodes':>10}{'Backtracks':>11}{'Checks':>10}{'Wipe-outs':>10}  solvable")
    rows = []
    for n in (5, 8, 12):
        acc = {"plain": [], "mac": []}; sat = 0
        for sd in range(SEEDS):
            rng = random.Random(100 * n + sd)
            edges = [(a, b) for a in range(n) for b in range(a + 1, n) if rng.random() < P]
            nb = neighbours_of(edges, n); dom0 = {i: set(range(1, SLOTS + 1)) for i in range(n)}
            c1, c2 = Counter(), Counter()
            s1 = backtrack_plain(n, dom0, nb, c1); s2 = backtrack_mac(n, dom0, nb, c2)
            assert (s1 is None) == (s2 is None), "methods disagree"
            if s1 is not None: assert valid(s1, edges) and valid(s2, edges)
            sat += s1 is not None
            acc["plain"].append(c1); acc["mac"].append(c2)
        for key, label in (("plain", "no propagation"), ("mac", "propagation")):
            m = lambda f: sum(f(c) for c in acc[key]) / SEEDS
            row = dict(n=n, method=label, nodes=m(lambda c: c.nodes), backtracks=m(lambda c: c.backtracks),
                       checks=m(lambda c: c.checks), wipeouts=m(lambda c: c.wipeouts), solvable=f"{sat}/{SEEDS}")
            rows.append(row)
            print(f"{n:>5}{label:>16}{row['nodes']:>10.1f}{row['backtracks']:>11.1f}{row['checks']:>10.1f}{row['wipeouts']:>10.1f}  {row['solvable']}")
    json.dump(rows, open("../results/task5.json", "w"), indent=1)

    fig, axes = plt.subplots(1, 2, figsize=(10, 3.8))
    for ax, metric, lab in zip(axes, ("nodes", "checks"), ("nodes visited", "constraint checks")):
        for label, mk in (("no propagation", "ro-"), ("propagation", "gs-")):
            ax.plot([5, 8, 12], [r[metric] for r in rows if r["method"] == label], mk, label=label)
        ax.set_yscale("log"); ax.set_xlabel("number of exams"); ax.set_ylabel(lab + " (log)"); ax.grid(alpha=.3); ax.legend()
    plt.tight_layout(); plt.savefig("../figs/fig7_task5_growth.png", dpi=130); plt.close()

"""TASK 7 - Diagnose the bottleneck of exhaustive search (Task 6), then design + test branch and bound."""
import itertools, math, time, json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from task6_tsp import make_instance

INF = float("inf")

def old_method(d, n):
    """Exhaustive search with operation counters (same logic as Task 6)."""
    best, tours, lookups = INF, 0, 0
    for perm in itertools.permutations(range(1, n + 1)):
        tours += 1
        L = d[0][perm[0]]; lookups += 1
        for i in range(n - 1): L += d[perm[i]][perm[i + 1]]; lookups += 1
        L += d[perm[-1]][0]; lookups += 1
        if L < best: best = L
    return dict(best=best, tours=tours, lookups=lookups)

def branch_and_bound(d, n, nearest_first=False):
    """Build the tour one customer at a time. FACT USED: distances are never negative, so a partial tour
    can only get longer; once partial >= best complete tour found so far it can never become the best."""
    st = dict(best=INF, tours=0, lookups=0, nodes=0, pruned=0)
    def rec(last, remaining, partial):
        st["nodes"] += 1
        if not remaining:
            total = partial + d[last][0]; st["lookups"] += 1; st["tours"] += 1
            if total < st["best"]: st["best"] = total
            return
        cand = sorted(remaining, key=lambda c: d[last][c]) if nearest_first else remaining
        for c in cand:
            newp = partial + d[last][c]; st["lookups"] += 1
            if newp >= st["best"]: st["pruned"] += 1; continue          # skip the whole subtree
            rec(c, [x for x in remaining if x != c], newp)
    first = list(range(1, n + 1))
    # first edge from the depot
    cand = sorted(first, key=lambda c: d[0][c]) if nearest_first else first
    for c in cand:
        st["lookups"] += 1
        if d[0][c] >= st["best"]: st["pruned"] += 1; continue
        rec(c, [x for x in first if x != c], d[0][c])
    return st

def bottleneck(d, n):
    """Diagnosis: how much of the exhaustive search's work happens AFTER the partial tour is already >= the optimum?"""
    opt = old_method(d, n)["best"]; wasted = total = 0; improvements = 0; best = INF; tours = 0
    for perm in itertools.permutations(range(1, n + 1)):
        tours += 1; L = 0; prev = 0; dead = False
        for c in perm + (0,):
            L += d[prev][c]; prev = c; total += 1
            if dead: wasted += 1
            elif L >= opt - 1e-12 and c != 0: dead = True
        if L < best: best = L; improvements += 1
    return dict(opt=opt, lookups=total, wasted=wasted, improvements=improvements, tours=tours)

if __name__ == "__main__":
    # ---------- A. bottleneck ----------
    print("A. BOTTLENECK DIAGNOSIS (exhaustive search, instance seed 11)")
    print(f"{'n':>3}{'tours':>9}{'lookups (n+1)*n!':>18}{'lookups after partial>=optimum':>32}{'wasted %':>10}{'times best improved':>21}")
    diag = []
    for n in (6, 7, 8, 9):
        pts, d = make_instance(n, 11); b = bottleneck(d, n); diag.append(dict(n=n, **b))
        print(f"{n:>3}{b['tours']:>9}{b['lookups']:>18}{b['wasted']:>32}{100 * b['wasted'] / b['lookups']:>10.1f}{b['improvements']:>21}")

    # ---------- E. implement and test ----------
    cases = [("n=7 seed 11", 7, 11), ("n=7 seed 12", 7, 12), ("n=7 seed 13", 7, 13),
             ("n=8 seed 11", 8, 11), ("n=8 seed 12", 8, 12), ("n=8 seed 13", 8, 13),
             ("n=9 seed 11", 9, 11), ("n=9 seed 12", 9, 12), ("n=9 seed 13", 9, 13),
             ("n=10 seed 11", 10, 11)]
    print("\nE. OLD (exhaustive) vs NEW-1 (branch and bound) vs NEW-2 (branch and bound + nearest-first)")
    hdr = f"{'Test case':<14}{'Old tours':>10}{'New1 tours':>11}{'New2 tours':>11}{'Old lookups':>12}{'New1 look.':>11}{'New2 look.':>11}{'Old s':>8}{'New1 s':>8}{'New2 s':>8}  Same?"
    print(hdr); rows = []
    for name, n, seed in cases + [("n=8 ALL EQUAL", 8, None)]:
        if seed is None: d = [[0 if i == j else 10.0 for j in range(9)] for i in range(9)]
        else: _, d = make_instance(n, seed)
        t0 = time.perf_counter(); o = old_method(d, n); to = time.perf_counter() - t0
        t0 = time.perf_counter(); n1 = branch_and_bound(d, n, False); t1 = time.perf_counter() - t0
        t0 = time.perf_counter(); n2 = branch_and_bound(d, n, True); t2 = time.perf_counter() - t0
        same = abs(o["best"] - n1["best"]) < 1e-9 and abs(o["best"] - n2["best"]) < 1e-9
        rows.append(dict(case=name, n=n, old_tours=o["tours"], new1_tours=n1["tours"], new2_tours=n2["tours"],
                         old_lookups=o["lookups"], new1_lookups=n1["lookups"], new2_lookups=n2["lookups"],
                         old_time=to, new1_time=t1, new2_time=t2, same=same, best=o["best"],
                         new1_nodes=n1["nodes"], new2_nodes=n2["nodes"]))
        print(f"{name:<14}{o['tours']:>10}{n1['tours']:>11}{n2['tours']:>11}{o['lookups']:>12}{n1['lookups']:>11}{n2['lookups']:>11}"
              f"{to:>8.3f}{t1:>8.3f}{t2:>8.3f}  {'Yes' if same else 'NO'}")
    print("\nReduction vs old (n = 9, mean of 3 seeds):")
    r9 = [r for r in rows if r["n"] == 9]
    for key in ("tours", "lookups"):
        for v in ("new1", "new2"):
            red = 100 * (1 - sum(r[f"{v}_{key}"] for r in r9) / sum(r[f"old_{key}"] for r in r9))
            print(f"  {v} {key}: {red:.2f}% fewer")
    json.dump(dict(diag=diag, rows=rows), open("../results/task7.json", "w"), indent=1)

    fig, axes = plt.subplots(1, 2, figsize=(10.5, 3.9))
    ok = [r for r in rows if r["case"].endswith(("11", "12", "13")) and "seed" in r["case"]]
    for n in (7, 8, 9):
        pass
    ns = [7, 8, 9]
    for key, mk, lab in (("old", "ro-", "old (exhaustive)"), ("new1", "bs-", "new: branch & bound"), ("new2", "g^-", "new + nearest-first")):
        axes[0].plot(ns, [sum(r[f"{key}_tours"] for r in rows if r["n"] == n and "seed" in r["case"]) / 3 for n in ns], mk, label=lab)
        axes[1].plot(ns, [sum(r[f"{key}_lookups"] for r in rows if r["n"] == n and "seed" in r["case"]) / 3 for n in ns], mk, label=lab)
    for ax, t in zip(axes, ("complete tours checked", "distance look-ups")):
        ax.set_yscale("log"); ax.set_xlabel("customers n"); ax.set_ylabel(t + " (mean of 3 seeds, log)"); ax.grid(alpha=.3); ax.legend(fontsize=8)
    plt.tight_layout(); plt.savefig("../figs/fig10_task7_compare.png", dpi=130); plt.close()

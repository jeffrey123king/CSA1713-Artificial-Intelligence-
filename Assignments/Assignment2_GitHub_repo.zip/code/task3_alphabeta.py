"""TASK 3 - How move ordering changes alpha-beta pruning (b=3, d=3 -> 27 leaves)."""
import random, json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

class Node:
    _next = 0
    def __init__(self, kids=None, val=None):
        self.kids, self.val = kids, val
        self.id = Node._next; Node._next += 1

def build(b, d, rng, lo=1, hi=99):
    if d == 0: return Node(val=rng.randint(lo, hi))
    return Node(kids=[build(b, d - 1, rng, lo, hi) for _ in range(b)])

def value(n, is_max):
    if n.kids is None: return n.val
    vals = [value(k, not is_max) for k in n.kids]
    return max(vals) if is_max else min(vals)

def reorder(n, is_max, mode, rng):
    """mode: 'best' (best move first at every level), 'worst' (best move last), 'random'."""
    if n.kids is None: return
    for k in n.kids: reorder(k, not is_max, mode, rng)
    if mode == "random": rng.shuffle(n.kids); return
    keyed = sorted(n.kids, key=lambda k: value(k, not is_max), reverse=is_max)   # best first
    n.kids = keyed if mode == "best" else keyed[::-1]

def make_equal(n, v=5):
    if n.kids is None: n.val = v
    else:
        for k in n.kids: make_equal(k, v)

def copy_tree(n):
    return Node(val=n.val) if n.kids is None else Node(kids=[copy_tree(k) for k in n.kids])

def minimax(n, is_max, st):
    st["nodes"] += 1; st["visited"].add(n.id)
    if n.kids is None: st["leaves"] += 1; return n.val
    vals = [minimax(k, not is_max, st) for k in n.kids]
    return max(vals) if is_max else min(vals)

def alphabeta(n, alpha, beta, is_max, st):
    st["nodes"] += 1; st["visited"].add(n.id)
    if n.kids is None: st["leaves"] += 1; return n.val
    if is_max:
        v = -10**9
        for k in n.kids:
            v = max(v, alphabeta(k, alpha, beta, False, st)); alpha = max(alpha, v)
            if alpha >= beta: st["cutoffs"] += 1; break
        return v
    v = 10**9
    for k in n.kids:
        v = min(v, alphabeta(k, alpha, beta, True, st)); beta = min(beta, v)
        if alpha >= beta: st["cutoffs"] += 1; break
    return v

def new_stats(): return dict(nodes=0, leaves=0, cutoffs=0, visited=set())

def run(tree):
    a, m = new_stats(), new_stats()
    va = alphabeta(tree, -10**9, 10**9, True, a); vm = minimax(tree, True, m)
    assert va == vm, "alpha-beta must return the minimax value"
    return a, m, va

def draw(ax, tree, visited, title):
    pos = {}; cnt = [0]
    def layout(n, depth):
        if n.kids is None: pos[n.id] = (cnt[0], -depth); cnt[0] += 1
        else:
            for k in n.kids: layout(k, depth + 1)
            pos[n.id] = (sum(pos[k.id][0] for k in n.kids) / len(n.kids), -depth)
    layout(tree, 0)
    def paint(n, is_max):
        for k in n.kids or []:
            vis = k.id in visited
            ax.plot([pos[n.id][0], pos[k.id][0]], [pos[n.id][1], pos[k.id][1]],
                    color="#2a7f2a" if vis else "#cccccc", lw=1.4 if vis else 0.8, zorder=1)
            paint(k, not is_max)
        x, y = pos[n.id]; vis = n.id in visited
        if n.kids is None:
            ax.text(x, y, str(n.val), ha="center", va="center", fontsize=7,
                    bbox=dict(boxstyle="round,pad=0.25", fc="#c8f0c8" if vis else "#eeeeee",
                              ec="#2a7f2a" if vis else "#bbbbbb"), color="k" if vis else "#999999", zorder=3)
        else:
            ax.plot(x, y, marker="^" if is_max else "v", ms=11, mfc="#ffd9a0" if vis else "#eeeeee",
                    mec="#aa6600" if vis else "#bbbbbb", zorder=3)
    paint(tree, True)
    ax.set_title(title, fontsize=9); ax.axis("off")

if __name__ == "__main__":
    rng = random.Random(7)
    base = build(3, 3, rng)
    treeA = copy_tree(base); reorder(treeA, True, "best", rng)
    treeB = copy_tree(base); reorder(treeB, True, "worst", rng)
    treeC = copy_tree(base); reorder(treeC, True, "random", random.Random(3))
    treeD = copy_tree(base); make_equal(treeD, 5)
    trees = {"A (best first)": treeA, "B (best last)": treeB, "C (random order)": treeC, "D (all leaves equal)": treeD}

    def leaves_of(n): return [n.val] if n.kids is None else [x for k in n.kids for x in leaves_of(k)]
    for name, t in trees.items():
        print(f"Tree {name} leaf values (left to right): {leaves_of(t)}")
    print()
    print(f"{'Tree':<24}{'Pred.':>6}{'Actual leaves':>14}{'Cutoffs':>9}{'Minimax leaves':>15}{'AB value':>9}")
    pred = {"A (best first)": 11, "B (best last)": 27, "C (random order)": 19, "D (all leaves equal)": 11}
    rows, stats_for_fig = [], {}
    for name, t in trees.items():
        a, m, v = run(t)
        rows.append(dict(tree=name, predicted=pred[name], actual=a["leaves"], cutoffs=a["cutoffs"],
                         minimax=m["leaves"], value=v, ab_nodes=a["nodes"], mm_nodes=m["nodes"]))
        stats_for_fig[name] = a["visited"]
        print(f"{name:<24}{pred[name]:>6}{a['leaves']:>14}{a['cutoffs']:>9}{m['leaves']:>15}{v:>9}")

    # ---- performance over depths / many random trees (b=3) ----
    print("\nAverage leaves visited by alpha-beta, b=3, 200 random trees per cell")
    print(f"{'depth':>5}{'minimax b^d':>12}{'best-first':>11}{'theory min':>11}{'random':>9}{'worst-first':>12}")
    perf = []
    for d in (2, 3, 4, 5, 6):
        res = {"best": [], "worst": [], "random": []}
        for s in range(200):
            r = random.Random(1000 * d + s); t0 = build(3, d, r)
            for mode in res:
                t = copy_tree(t0); reorder(t, True, mode, random.Random(s)); a, m, _ = run(t)
                res[mode].append(a["leaves"])
        avg = {k: sum(v) / len(v) for k, v in res.items()}
        theory = 3 ** ((d + 1) // 2) + 3 ** (d // 2) - 1
        perf.append(dict(depth=d, minimax=3 ** d, best=avg["best"], theory=theory, random=avg["random"], worst=avg["worst"]))
        print(f"{d:>5}{3**d:>12}{avg['best']:>11.1f}{theory:>11}{avg['random']:>9.1f}{avg['worst']:>12.1f}")
    json.dump(dict(rows=rows, perf=perf), open("../results/task3.json", "w"), indent=1)

    fig, axes = plt.subplots(3, 1, figsize=(11, 10))
    for ax, name in zip(axes, ["A (best first)", "B (best last)", "C (random order)"]):
        r = [x for x in rows if x["tree"] == name][0]
        draw(ax, trees[name], stats_for_fig[name], f"Tree {name}: alpha-beta visits {r['actual']} of 27 leaves "
             f"({r['cutoffs']} cutoffs)   [green = visited, grey = pruned; ^ = MAX, v = MIN]")
    plt.tight_layout(); plt.savefig("../figs/fig4_task3_trees.png", dpi=130); plt.close()

    fig, ax = plt.subplots(figsize=(6.5, 4))
    ds = [p["depth"] for p in perf]
    ax.plot(ds, [p["minimax"] for p in perf], "k--o", label="plain minimax (b^d)")
    ax.plot(ds, [p["worst"] for p in perf], "r-o", label="alpha-beta, worst order")
    ax.plot(ds, [p["random"] for p in perf], "b-o", label="alpha-beta, random order")
    ax.plot(ds, [p["best"] for p in perf], "g-o", label="alpha-beta, best order")
    ax.set_yscale("log"); ax.set_xlabel("depth d (b = 3)"); ax.set_ylabel("leaves visited (log)")
    ax.legend(); ax.grid(alpha=.3); plt.tight_layout(); plt.savefig("../figs/fig5_task3_growth.png", dpi=130); plt.close()

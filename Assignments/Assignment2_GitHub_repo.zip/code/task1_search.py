"""TASK 1 - UCS vs Greedy Best-First vs A* on campus grid maps (Python 3)."""
import heapq, json, random
from collections import deque
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap

MAP_A = """S..............
...#...........
...#.......#...
...#...........
.......##......
.......##......
..#............
..#....#.......
.......#...#...
...............
.....#.........
.....#....##...
...............
.......#.......
..............G""".split("\n")

MAP_B = """...............
...............
...............
.....#...#.....
.....#...#.....
..#..#...#.....
..#..#...#.....
S.#.....##...G.
..#..#...#.....
..#..#...#.....
..#..#...#.....
..#.....##.....
..#..#...#.....
.....#...#.....
.....#...#.....""".split("\n")

MAP_C = """S..............
...............
...............
...............
...............
...............
.......#.......
......#G#......
.......#.......
...............
...............
...............
...............
...............
...............""".split("\n")

def parse(rows, same_start_goal=False):
    grid, start, goal = [], None, None
    for r, line in enumerate(rows):
        row = []
        for c, ch in enumerate(line):
            row.append(1 if ch == "#" else 0)
            if ch == "S": start = (r, c)
            if ch == "G": goal = (r, c)
        grid.append(row)
    if same_start_goal: goal = start
    return grid, start, goal

def manhattan(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

def neighbors(grid, p):
    r, c = p
    for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
        nr, nc = r + dr, c + dc
        if 0 <= nr < len(grid) and 0 <= nc < len(grid[0]) and grid[nr][nc] == 0:
            yield (nr, nc)

def search(grid, start, goal, algo):
    """algo in {'UCS','Greedy','A*'}. Returns dict of metrics (+ path, closed set)."""
    h = lambda p: manhattan(p, goal)
    def key(g, p):
        if algo == "UCS": return (g, 0)
        if algo == "Greedy": return (h(p), 0)
        return (g + h(p), h(p))            # A*: tie-break toward smaller h
    counter = 0
    g_best, parent = {start: 0}, {start: None}
    frontier = [(key(0, start), counter, start)]
    open_set, closed = {start}, set()
    expanded, generated, max_frontier = 0, 1, 1
    while frontier:
        _, _, p = heapq.heappop(frontier)
        if p in closed: continue
        open_set.discard(p); closed.add(p); expanded += 1
        if p == goal:
            path, q = [], p
            while q is not None: path.append(q); q = parent[q]
            return dict(expanded=expanded, generated=generated, max_frontier=max_frontier,
                        cost=g_best[p], path=path[::-1], closed=closed)
        for q in neighbors(grid, p):
            ng = g_best[p] + 1
            if q in closed: continue
            if algo == "Greedy":
                if q in g_best: continue
            elif q in g_best and ng >= g_best[q]: continue
            g_best[q] = ng; parent[q] = p; counter += 1
            heapq.heappush(frontier, (key(ng, q), counter, q))
            open_set.add(q); generated += 1
        max_frontier = max(max_frontier, len(open_set))
    return dict(expanded=expanded, generated=generated, max_frontier=max_frontier,
                cost=None, path=[], closed=closed)

ALGOS = ["UCS", "Greedy", "A*"]

def run_map(name, grid, s, g):
    res = {a: search(grid, s, g, a) for a in ALGOS}
    opt = res["UCS"]["cost"]
    rows = []
    for a in ALGOS:
        r = res[a]
        optimal = "N/A (no path)" if opt is None else ("Yes" if r["cost"] == opt else "No")
        rows.append(dict(map=name, algo=a, expanded=r["expanded"], generated=r["generated"],
                         max_frontier=r["max_frontier"],
                         cost=("no path" if r["cost"] is None else r["cost"]), optimal=optimal))
    return rows, res

def random_grid(n, density, rng):
    grid = [[1 if rng.random() < density else 0 for _ in range(n)] for _ in range(n)]
    grid[0][0] = 0; grid[n - 1][n - 1] = 0
    return grid

if __name__ == "__main__":
    maps = {"A": parse(MAP_A), "B": parse(MAP_B), "C": parse(MAP_C),
            "C2 (start=goal)": parse(MAP_A, same_start_goal=True)}
    table, allres = [], {}
    for name, (grid, s, g) in maps.items():
        rows, res = run_map(name, grid, s, g); table += rows; allres[name] = res
    print(f"{'Map':<16}{'Algorithm':<8}{'Expanded':>9}{'Generated':>10}{'MaxFront':>9}{'Cost':>9}  Optimal?")
    for r in table:
        print(f"{r['map']:<16}{r['algo']:<8}{r['expanded']:>9}{r['generated']:>10}{r['max_frontier']:>9}{str(r['cost']):>9}  {r['optimal']}")

    print()
    for name in ("A", "B"):       # admissibility check: h(n) <= true remaining cost (BFS from goal)
        grid, s, g = maps[name]
        dist = {g: 0}; dq = deque([g])
        while dq:
            p = dq.popleft()
            for q in neighbors(grid, p):
                if q not in dist: dist[q] = dist[p] + 1; dq.append(q)
        bad = sum(1 for p, d in dist.items() if manhattan(p, g) > d)
        print(f"Admissibility check Map {name}: cells with h > true distance = {bad} (of {len(dist)} reachable)")

    rng = random.Random(2026)
    stats = []
    print("\nRandom maps: 30 seeds per row (unsolvable maps skipped)")
    print(f"{'size':>5}{'dens':>6}{'algo':>8}{'avg_exp':>9}{'avg_gen':>9}{'avg_front':>10}{'%optimal':>9}{'avg_cost':>9}")
    for n in (15, 30, 60):
        for dens in (0.10, 0.30):
            agg = {a: dict(e=[], g=[], f=[], c=[], o=[]) for a in ALGOS}
            used = 0
            while used < 30:
                grid = random_grid(n, dens, rng)
                s, g = (0, 0), (n - 1, n - 1)
                res = {a: search(grid, s, g, a) for a in ALGOS}
                if res["UCS"]["cost"] is None: continue
                used += 1
                for a in ALGOS:
                    agg[a]["e"].append(res[a]["expanded"]); agg[a]["g"].append(res[a]["generated"])
                    agg[a]["f"].append(res[a]["max_frontier"]); agg[a]["c"].append(res[a]["cost"])
                    agg[a]["o"].append(res[a]["cost"] == res["UCS"]["cost"])
            for a in ALGOS:
                m = lambda x: sum(x) / len(x)
                row = dict(size=n, density=dens, algo=a, expanded=round(m(agg[a]["e"]), 1),
                           generated=round(m(agg[a]["g"]), 1), frontier=round(m(agg[a]["f"]), 1),
                           pct_optimal=round(100 * m(agg[a]["o"]), 1), cost=round(m(agg[a]["c"]), 2))
                stats.append(row)
                print(f"{n:>5}{dens:>6}{a:>8}{row['expanded']:>9}{row['generated']:>9}{row['frontier']:>10}{row['pct_optimal']:>9}{row['cost']:>9}")

    json.dump(dict(table=table, stats=stats), open("../results/task1.json", "w"), indent=1)

    fig, axes = plt.subplots(3, 3, figsize=(10, 10))
    cmap = ListedColormap(["white", "black", "#bfe3ff"])
    for i, name in enumerate(("A", "B", "C")):
        grid, s, g = maps[name]
        for j, a in enumerate(ALGOS):
            ax = axes[i][j]; r = allres[name][a]
            mat = [row[:] for row in grid]
            for (rr, cc) in r["closed"]: mat[rr][cc] = 2
            ax.imshow(mat, cmap=cmap, vmin=0, vmax=2)
            if r["path"]:
                ax.plot([p[1] for p in r["path"]], [p[0] for p in r["path"]], color="red", lw=2)
            ax.plot(s[1], s[0], "go", ms=9); ax.plot(g[1], g[0], marker="*", color="gold", mec="k", ms=15)
            cost = "no path" if r["cost"] is None else f"cost {r['cost']}"
            ax.set_title(f"Map {name} - {a}\nexpanded {r['expanded']}, {cost}", fontsize=9)
            ax.set_xticks([]); ax.set_yticks([])
    plt.tight_layout(); plt.savefig("../figs/fig1_task1_maps.png", dpi=130); plt.close()

    fig, axes = plt.subplots(1, 2, figsize=(10, 3.8))
    for ax, dens in zip(axes, (0.10, 0.30)):
        for k, a in enumerate(ALGOS):
            vals = [x["expanded"] for x in stats if x["algo"] == a and x["density"] == dens]
            ax.bar([i + 0.27 * (k - 1) for i in range(3)], vals, 0.27, label=a)
        ax.set_xticks(range(3)); ax.set_xticklabels(["15x15", "30x30", "60x60"])
        ax.set_yscale("log"); ax.set_ylabel("avg nodes expanded (log)")
        ax.set_title(f"Random maps, {int(dens*100)}% blocked"); ax.legend()
    plt.tight_layout(); plt.savefig("../figs/fig2_task1_random.png", dpi=130); plt.close()

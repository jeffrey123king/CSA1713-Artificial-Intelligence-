# AI (CSA17) - Assignment 2 (CO2)
Python 3 (Jupyter / Colab). Run each script from the `code/` folder, e.g. `python task1_search.py`.
Task 7 imports Task 6 (`task6_tsp.py`), keep them together. Needs: matplotlib, numpy.
- code/     source for Tasks 1-7
- outputs/  captured program output (task1_output.txt ... task7_output.txt)
- figs/     figures used in the report
- results/  raw experiment data (JSON)
- predictions_BEFORE_RUNNING.md  predictions written before running
Seeds are fixed, so counts reproduce exactly; timings vary by machine.

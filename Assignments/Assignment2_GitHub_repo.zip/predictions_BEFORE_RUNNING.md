# Predictions written BEFORE any experiment code was executed
Task1: Map A (open) -> Greedy expands fewest (it walks straight at the goal). Map B (maze + trap) -> A* expands fewest
       (informed + never walks far into a pocket whose f > optimal cost). Map C (goal enclosed) -> all three tie
       (no path exists, each must exhaust the reachable region). Start==goal case -> all three expand 1 node.
Task3: Tree A (best-first) -> 11 leaves (b^ceil(d/2)+b^floor(d/2)-1 = 9+3-1). Tree B (worst-first) -> 27 leaves.
       Tree C (random order) -> about 19 leaves (between 11 and 27). All-equal-leaves tree -> 11 leaves.
Task4: Nodes for 3x3 at depth d = 1+9+72+... (falling factorial, b shrinks by 1 each ply); 4x4 depth d = 1+16+240+... 
       Expect actual counts to equal these exactly for d <= 4 (3x3) / d <= 6 (4x4) because no win is possible earlier.
Task6: n=5 -> 120 tours, n=7 -> 5040, n=9 -> 362880. Time x ~ (n+1)x per extra customer.
Task7: Branch-and-bound should cut complete tours checked at n=9 by >= 70%.

# Task 7 (written before running task7 code)
Chosen problem: Task 6 exhaustive search. Idea: branch and bound - stop extending a partial tour once its length >= best complete tour so far.
Prediction: Same optimal distance in every test. Complete tours checked at n=9 should fall by well over 90% (goal >= 70%), edge look-ups
should fall even more because shared prefixes are no longer recomputed. Nearest-first ordering should help further.
Expected failure case: if all distances are equal nothing can be pruned, so tours checked stays n!.
